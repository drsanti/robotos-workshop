"""Node, Publisher, Subscriber — thin wrappers over the C ABI.

Callback contract (ADR-0018): ``robotos_message_callback_t`` fires on
a robotos-managed worker thread and must not call robotos functions
reentrantly. We therefore marshal every delivery through a bounded
``queue.Queue`` to a daemon thread that invokes the user callable —
``publish()`` inside a callback stays legal. The trampoline
(``CFUNCTYPE``) is retained on the Subscriber for its lifetime; GC
freeing it mid-call is the crash the ADR warns about.
"""

from __future__ import annotations

import ctypes
import queue
import threading
import time
from typing import Any, Callable, Optional

from . import _ffi
from .errors import CHANNEL_CLOSED, SHUTDOWN, TIMEOUT, RobotosError, check

WAIT_FOREVER = 0xFFFFFFFF


def _schema_id(message_type: Any) -> str:
    """Canonical protobuf name — what crosses the ABI.

    Accepts a generated ``*_pb2`` class (``DESCRIPTOR.full_name``),
    an instance, or a plain schema-id string.
    """
    if isinstance(message_type, str):
        return message_type
    cls = message_type if isinstance(message_type, type) else type(message_type)
    return cls.DESCRIPTOR.full_name


def _encode(message_type: Any, msg: Any) -> bytes:
    if isinstance(msg, (bytes, bytearray)):
        return bytes(msg)
    return msg.SerializeToString()


class Publisher:
    def __init__(self, handle: int, message_type: Any):
        self._handle = handle
        self._type = message_type

    def publish(self, msg: Any) -> None:
        """Accepted for local transport — never end-to-end receipt."""
        data = _encode(self._type, msg)
        buf = (ctypes.c_uint8 * max(len(data), 1)).from_buffer_copy(
            data or b"\x00")
        check(
            _ffi.robotos_publish(self._handle, buf, len(data)),
            "publish")

    def close(self) -> None:
        if self._handle:
            _ffi.robotos_publisher_destroy(self._handle)
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class Subscriber:
    """Poll via ``recv()`` or arm a callback — mutually exclusive per
    ADR-0006 (arm after recv'd, or recv until armed; the ABI enforces
    it by failing whichever comes second)."""

    def __init__(self, handle: int, message_type: Any):
        self._handle = handle
        self._type = message_type
        self._cb_trampoline = None      # CFUNCTYPE — must outlive armed cb
        self._cb_thread = None
        self._cb_queue = None
        self._guard = _ffi.HandleGuard()

    # -- blocking poll ------------------------------------------------------

    def recv(self, timeout_ms: int = WAIT_FOREVER) -> Any:
        """Decoded message, or raises RobotosError (TIMEOUT on expiry).

        Polls internally in <=1 s slices — a WAIT_FOREVER recv can
        still be interrupted by KeyboardInterrupt or closed from
        another thread (the destroy waits for this call to leave)."""
        deadline = (None if timeout_ms == WAIT_FOREVER
                    else time.monotonic() + timeout_ms / 1000.0)
        while True:
            if not self._guard.enter():
                raise RobotosError(SHUTDOWN, "subscriber closed")
            try:
                slice_ms = 1000
                if deadline is not None:
                    left = deadline - time.monotonic()
                    if left <= 0:
                        raise TimeoutError("recv timed out")
                    slice_ms = min(1000, int(left * 1000) or 1)
                msg = _ffi.Message()
                st = _ffi.robotos_subscriber_recv_owned(
                    self._handle, ctypes.byref(msg), slice_ms)
            finally:
                self._guard.exit()
            if st == TIMEOUT:
                continue
            if st in (CHANNEL_CLOSED, SHUTDOWN):
                raise RobotosError(st, "recv")
            check(st, "recv")
            try:
                data = ctypes.string_at(msg.data, msg.len)
            finally:
                _ffi.robotos_message_free(ctypes.byref(msg))
            return self._decode(data)

    def _decode(self, data: bytes) -> Any:
        cls = self._type if isinstance(self._type, type) else None
        if cls is None:
            return data
        m = cls()
        m.ParseFromString(data)
        return m

    # -- callback delivery --------------------------------------------------

    def on_message(
        self, cb: Callable[[Any, dict], None], queue_depth: int = 64
    ) -> None:
        """Marshal deliveries onto a daemon thread — `cb` may safely
        call robotos APIs (publish etc.) since it never runs on the
        ABI worker thread. Queue overflow drops the oldest delivery."""
        if self._cb_trampoline is not None:
            raise RobotosError(9, "on_message: already armed")
        q: queue.Queue = queue.Queue(maxsize=queue_depth)
        self._cb_queue = q

        def _pump():
            while True:
                item = q.get()
                if item is None:           # sentinel on close
                    return
                data, meta = item
                try:
                    cb(self._decode(data), meta)
                except Exception:
                    pass                    # user error must not kill the pump

        def _trampoline(data_ptr, length, meta_ptr, _user):
            data = ctypes.string_at(data_ptr, length)
            m = {
                "publisher_uuid":
                    meta_ptr.contents.publisher_uuid.decode("ascii",
                                                            "replace"),
                "sequence": meta_ptr.contents.sequence,
                "timestamp_ns": meta_ptr.contents.timestamp_ns,
            }
            try:
                q.put_nowait((data, m))
            except queue.Full:
                try:
                    q.get_nowait()           # drop oldest
                    q.put_nowait((data, m))
                except queue.Empty:
                    pass

        self._cb_trampoline = _ffi.MESSAGE_CALLBACK(_trampoline)
        self._cb_thread = threading.Thread(target=_pump, daemon=True)
        self._cb_thread.start()
        check(
            _ffi.robotos_subscriber_set_callback(
                self._handle, self._cb_trampoline, None),
            "on_message")

    def close(self) -> None:
        if (self._cb_thread is not None
                and threading.current_thread() is self._cb_thread):
            # Called from inside a callback — joining the pump thread
            # from itself deadlocks; defer the teardown.
            threading.Thread(target=self.close, daemon=True).start()
            return
        if self._cb_trampoline is not None:
            _ffi.robotos_subscriber_clear_callback(self._handle)
            try:
                self._cb_queue.put_nowait(None)  # stop pump thread
            except queue.Full:
                pass
            self._cb_thread.join(timeout=2.0)
            self._cb_trampoline = None        # safe to free now
        self._guard.close()
        if self._handle:
            _ffi.robotos_subscriber_destroy(self._handle)
            self._handle = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class Node:
    """A robotos node — owns the Tokio runtime and transport session."""

    def __init__(
        self,
        name: str,
        listen_endpoints: str | None = None,
        connect_endpoints: str | None = None,
        domain: int = 0,
        multicast: bool = True,
    ):
        h = ctypes.c_void_p()
        if listen_endpoints is None and connect_endpoints is None and \
                domain == 0 and multicast:
            check(
                _ffi.robotos_node_create(
                    name.encode(), ctypes.byref(h)),
                "node_create")
        else:
            check(
                _ffi.robotos_node_create_with_transport(
                    name.encode(),
                    (listen_endpoints or "").encode() or None,
                    (connect_endpoints or "").encode() or None,
                    domain, 1 if multicast else 0, ctypes.byref(h)),
                "node_create_with_transport")
        self._handle = h.value
        self._children = []
        self._hook_refs = []

    # -- pub / sub -----------------------------------------------------------

    def create_publisher(
        self, topic: str, message_type: Any
    ) -> Publisher:
        h = ctypes.c_void_p()
        check(
            _ffi.robotos_publisher_create(
                self._handle, topic.encode(),
                _schema_id(message_type).encode(), ctypes.byref(h)),
            "create_publisher")
        pub = Publisher(h.value, message_type)
        self._children.append(pub)
        return pub

    def create_subscriber(
        self, topic: str, message_type: Any
    ) -> Subscriber:
        h = ctypes.c_void_p()
        check(
            _ffi.robotos_subscriber_create(
                self._handle, topic.encode(),
                _schema_id(message_type).encode(), ctypes.byref(h)),
            "create_subscriber")
        sub = Subscriber(h.value, message_type)
        self._children.append(sub)
        return sub

    # -- services (unary RPC) ---------------------------------------------------

    def create_service(
        self, name: str, req_type: Any, resp_type: Any,
        handler: Callable[[Any], Any],
    ) -> "Service":
        """Declare a unary service — handler runs on a daemon pump
        thread (safe to call robotos APIs inside)."""
        from .service import Service
        svc = Service.create(self, name, req_type, resp_type, handler)
        self._children.append(svc)
        return svc

    def call(
        self, name: str, req_type: Any, resp_type: Any, req: Any,
        timeout_ms: int = 5000,
    ) -> Any:
        """Unary client call — raises RobotosError (UNAVAILABLE until
        the queryable propagates; retry with backoff)."""
        from .service import client_call
        return client_call(
            self, name, req_type, resp_type, req, timeout_ms)

    # -- parameters ---------------------------------------------------------------

    def declare_parameter(
        self, name: str, value, description: str = "",
        read_only: bool = False, value_range=None,
    ) -> None:
        from . import params
        params.declare(
            self, name, value, description, read_only, value_range)

    def param_get(self, name: str, kind: str | None = None):
        from . import params
        return params.get(self, name, kind)

    def param_set(self, name: str, value) -> None:
        from . import params
        params.set_(self, name, value)

    def set_allow_remote_params(self, allow: bool) -> None:
        _ffi.robotos_param_allow_remote(self._handle, 1 if allow else 0)

    # -- actions (long-running goals) --------------------------------------------

    def create_action(
        self, name: str, goal_type, feedback_type, result_type,
        handler,
    ) -> "ActionServer":
        """Declare an action — `handler(goal, ctx) -> result` on a
        daemon pump thread; ctx.send_feedback / cancel_requested
        are legal inside it."""
        from .action import ActionServer
        srv = ActionServer.create(
            self, name, goal_type, feedback_type, result_type, handler)
        self._children.append(srv)
        return srv

    def action_client(
        self, name: str, goal_type, feedback_type, result_type,
    ) -> "ActionClient":
        from .action import ActionClient
        cli = ActionClient.create(
            self, name, goal_type, feedback_type, result_type)
        self._children.append(cli)
        return cli

    # -- record / replay -----------------------------------------------------------

    def recorder(
        self, topics: list, path: str, label: str = "",
    ) -> "Recorder":
        from .record import Recorder
        rec = Recorder.create(self, topics, path, label)
        self._children.append(rec)
        return rec

    def replay(self, path: str, rate: float = 1.0,
               allow_command_topics: bool = False,
               topics=None, prefix=None) -> dict:
        from .record import replay
        return replay(self, path, rate, allow_command_topics,
                      topics, prefix)

    def graph_json(self, settle_ms: int = 1600) -> str:
        """Presence graph as JSON — `{"nodes":[{uuid,name,lifecycle,
        endpoints:[{topic,kind,schema,qos}]}]}`."""
        import ctypes as _ct
        need = _ct.c_size_t(0)
        _ffi.robotos_node_graph_json(
            self._handle, settle_ms, None, 0, _ct.byref(need))
        buf = _ct.create_string_buffer(need.value + 1)
        check(
            _ffi.robotos_node_graph_json(
                self._handle, settle_ms, buf, len(buf), _ct.byref(need)),
            "graph_json")
        return buf.value.decode()

    # -- presence (zenoh liveliness) ------------------------------------------

    def presence_get(self, keyexpr: str = "robotos/0/presence/*") -> list[str]:
        """One-shot — keyexprs of liveliness tokens alive now."""
        out: list[str] = []

        @_ffi.PRESENCE_CALLBACK
        def _cb(ke, state, _u):
            if state == 1 and ke:
                out.append(ke.decode())

        check(
            _ffi.robotos_presence_get(
                self._handle, keyexpr.encode(), _cb, None, None),
            "presence_get")
        return out

    def presence_watch(
        self,
        keyexpr: str,
        cb: Callable[[str, bool], None],
    ) -> "PresenceWatcher":
        from .presence import PresenceWatcher
        w = PresenceWatcher.create(self, keyexpr, cb)
        self._children.append(w)
        return w

    def presence_declare(self, keyexpr: str) -> "PresenceToken":
        from .presence import PresenceToken
        t = PresenceToken.create(self, keyexpr)
        self._children.append(t)
        return t

    # -- lifecycle -------------------------------------------------------------

    LIFECYCLE = {
        "unspecified": 0, "created": 1, "inactive": 2, "active": 3,
        "finalized": 4, "configuring": 5, "activating": 6,
        "deactivating": 7, "cleaningup": 8, "shuttingdown": 9,
        "error": 10,
    }
    _LC_HOOK = {"configure": 0, "activate": 1, "deactivate": 2,
                "cleanup": 3}

    def lifecycle_state(self) -> int:
        """Current lifecycle state (ROBOTOS_LIFECYCLE_*)."""
        return _ffi.robotos_lifecycle_get(self._handle)

    def configure(self) -> None:
        check(_ffi.robotos_lifecycle_configure(self._handle),
              "lifecycle configure")

    def activate(self) -> None:
        check(_ffi.robotos_lifecycle_activate(self._handle),
              "lifecycle activate")

    def deactivate(self) -> None:
        check(_ffi.robotos_lifecycle_deactivate(self._handle),
              "lifecycle deactivate")

    def cleanup(self) -> None:
        check(_ffi.robotos_lifecycle_cleanup(self._handle),
              "lifecycle cleanup")

    def allow_remote_lifecycle(self, allow: bool = True) -> None:
        """Opt in to remote lifecycle mutation (off by default)."""
        _ffi.robotos_lifecycle_allow_remote(self._handle, int(allow))

    def on_lifecycle(self, transition: str, fn: Callable[[], bool]) -> None:
        """Hook a transition (configure|activate|deactivate|cleanup).

        `fn` runs inside the transition; returning False or raising
        fails it and the node enters Error — recover via cleanup()."""
        which = self._LC_HOOK[transition]

        @_ffi.LIFECYCLE_CB
        def _cb(_ud):
            try:
                return 0 if fn() else 1
            except Exception:
                return 1

        check(
            _ffi.robotos_lifecycle_on(self._handle, which, _cb, None),
            f"on_lifecycle {transition}")
        self._hook_refs.append(_cb)  # keep the trampoline alive

    def on_param_set(self, fn: Callable[[str, str, str], bool]) -> None:
        """Pre-commit veto hook — runs synchronously inside set().

        `fn(name, new_value, old_value)` returns True to accept;
        False/raise rejects the set (caller sees the error, no event
        is emitted). Must not call back into the params API — the
        table lock is held."""
        @_ffi.PARAM_SET_CB
        def _cb(name, _type, new, old, _ud):
            try:
                ok = fn(name.decode(), new.decode(), old.decode())
                return 0 if ok else 1
            except Exception:
                return 1

        check(
            _ffi.robotos_param_on_set(self._handle, _cb, None),
            "param_on_set")
        self._hook_refs.append(_cb)

    def shutdown(self) -> None:
        if self._handle:
            _ffi.robotos_node_shutdown(self._handle)

    def close(self) -> None:
        self.shutdown()
        first_err = None
        for c in list(self._children):
            try:
                c.close()
            except Exception as e:        # one bad child can't strand the rest
                first_err = first_err or e
            finally:
                self._children.remove(c)
        if self._handle:
            _ffi.robotos_node_destroy(self._handle)
            self._handle = None
        if first_err:
            raise first_err
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    @staticmethod
    def version() -> str:
        return _ffi.robotos_get_version().decode()

    @staticmethod
    def abi_version() -> int:
        return _ffi.robotos_abi_version()
