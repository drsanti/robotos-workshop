"""Presence — session-backed liveliness tokens (zenoh).

Distinct from the graph heartbeat: a liveliness token dies WITH the
transport session, so UP/DOWN is authoritative, not a staleness
guess. Keys are raw key expressions (e.g. ``robotos/0/presence/*``),
not domain topics.

Client mode is required for declarations to relay through a remote
listener — set ``ROBOTOS_MODE=client`` (same constraint as the
``robotos presence`` CLI).
"""

from __future__ import annotations

import ctypes
import queue
import threading
from typing import Callable

from . import _ffi
from .errors import check


class PresenceToken:
    """Held liveliness declaration — dropping it withdraws early;
    transport session drop withdraws it regardless."""

    def __init__(self, handle: int):
        self._handle = handle

    @classmethod
    def create(cls, node, keyexpr: str) -> "PresenceToken":
        h = ctypes.c_void_p()
        check(
            _ffi.robotos_presence_declare(
                node._handle, keyexpr.encode(), ctypes.byref(h)),
            "presence_declare")
        return cls(h.value)

    def close(self) -> None:
        if self._handle:
            _ffi.robotos_presence_token_destroy(self._handle)
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class PresenceWatcher:
    """Stream of UP/DOWN events under a keyexpr; replays tokens
    alive at subscribe time. Callbacks are marshalled onto a daemon
    thread — user code may call robotos APIs freely."""

    def __init__(self):
        self._handle = None
        self._cb_trampoline = None
        self._thread = None
        self._queue = None

    @classmethod
    def create(
        cls, node, keyexpr: str, cb: Callable[[str, bool], None]
    ) -> "PresenceWatcher":
        w = cls()
        q: queue.Queue = queue.Queue(maxsize=64)
        w._queue = q

        def _pump():
            while True:
                item = q.get()
                if item is None:
                    return
                ke, alive = item
                try:
                    cb(ke, alive)
                except Exception:
                    pass

        def _trampoline(ke_ptr, state, _user):
            ke = ke_ptr.decode() if ke_ptr else ""
            alive = state == 1
            try:
                q.put_nowait((ke, alive))
            except queue.Full:
                try:
                    q.get_nowait()
                    q.put_nowait((ke, alive))
                except queue.Empty:
                    pass

        w._cb_trampoline = _ffi.PRESENCE_CALLBACK(_trampoline)
        w._thread = threading.Thread(target=_pump, daemon=True)
        w._thread.start()
        h = ctypes.c_void_p()
        try:
            check(
                _ffi.robotos_presence_watch(
                    node._handle, keyexpr.encode(),
                    w._cb_trampoline, None, ctypes.byref(h)),
                "presence_watch")
        except Exception:
            q.put(None)
            w._thread.join(timeout=2.0)
            raise
        w._handle = h.value
        return w

    def close(self) -> None:
        if self._handle:
            # cancels + joins the ABI task; user_data no longer referenced
            _ffi.robotos_presence_watch_destroy(self._handle)
            self._handle = None
            self._queue.put(None)
            self._thread.join(timeout=2.0)
            self._cb_trampoline = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
