"""ctypes bindings for librobotos_ffi (private — use the public API).

Library discovery order:
  1. bundled ``robotos/_native/librobotos_ffi.*`` (packaged wheels)
  2. ``$ROBOTOS_FFI_LIB`` explicit path
  3. cargo target dir (``<repo>/target/{release,debug}``) for dev
"""

from __future__ import annotations

import ctypes
import os
import sys
from pathlib import Path

_LIB_NAMES = {
    "darwin": "librobotos_ffi.dylib",
    "linux": "librobotos_ffi.so",
    "win32": "robotos_ffi.dll",
}


def _find_lib() -> str:
    here = Path(__file__).resolve().parent
    candidates = [
        here / "_native" / _LIB_NAMES.get(sys.platform, "librobotos_ffi.so"),
    ]
    env = os.environ.get("ROBOTOS_FFI_LIB")
    if env:
        candidates.insert(0, Path(env))
    # dev fallback: <repo>/target/{release,debug} — this file lives at
    # <repo>/sdk/python/robotos/_ffi.py
    repo = here.parent.parent.parent
    for profile in ("release", "debug"):
        candidates.append(
            repo / "target" / profile / _LIB_NAMES.get(
                sys.platform, "librobotos_ffi.so")
        )
    for c in candidates:
        if c.is_file():
            return str(c)
    names = ", ".join(str(c) for c in candidates)
    raise RuntimeError(f"librobotos_ffi not found; searched: {names}")


lib = ctypes.CDLL(_find_lib())

# ---- types ---------------------------------------------------------------

_c_char_p = ctypes.c_char_p
_u8_p = ctypes.POINTER(ctypes.c_uint8)
_size_t = ctypes.c_size_t
_u32 = ctypes.c_uint32
_u64 = ctypes.c_uint64
_u16 = ctypes.c_uint16
_i32 = ctypes.c_int32
_void_p = ctypes.c_void_p


class MsgMeta(ctypes.Structure):
    _fields_ = [
        ("struct_size", _u32),
        ("publisher_uuid", ctypes.c_char * 37),
        ("sequence", _u64),
        ("timestamp_ns", _u64),
    ]


class Message(ctypes.Structure):
    _fields_ = [
        ("struct_size", _u32),
        ("data", _u8_p),
        ("len", _size_t),
        ("meta", MsgMeta),
    ]


MESSAGE_CALLBACK = ctypes.CFUNCTYPE(
    None, _u8_p, _size_t, ctypes.POINTER(MsgMeta), _void_p)
PRESENCE_CALLBACK = ctypes.CFUNCTYPE(None, _c_char_p, _u32, _void_p)
# u32 handler(req, req_len, resp_buf, resp_cap, resp_len_out, user)
SERVICE_HANDLER = ctypes.CFUNCTYPE(
    _u32, _u8_p, _size_t, _u8_p, _size_t, ctypes.POINTER(_size_t), _void_p)
# int veto(name, type, new_value, old_value, user) — 0 accept
PARAM_SET_CB = ctypes.CFUNCTYPE(
    _i32, _c_char_p, _i32, _c_char_p, _c_char_p, _void_p)
# int hook(user) — 0 ok, nonzero fails the transition
LIFECYCLE_CB = ctypes.CFUNCTYPE(_i32, _void_p)


class ParamDescriptor(ctypes.Structure):
    _fields_ = [
        ("struct_size", _u32),
        ("description", _c_char_p),
        ("read_only", ctypes.c_uint8),
        ("has_range", ctypes.c_uint8),
        ("range_min", ctypes.c_double),
        ("range_max", ctypes.c_double),
    ]

# ---- signatures ------------------------------------------------------------


def _sig(name: str, restype, argtypes):
    fn = getattr(lib, name)
    fn.restype = restype
    fn.argtypes = argtypes
    return fn


robotos_abi_version = _sig("robotos_abi_version", _u32, [])
robotos_get_version = _sig("robotos_get_version", _c_char_p, [])
robotos_last_error = _sig("robotos_last_error", _c_char_p, [])

robotos_node_create = _sig(
    "robotos_node_create", _u32,
    [_c_char_p, ctypes.POINTER(_void_p)])
robotos_node_create_with_transport = _sig(
    "robotos_node_create_with_transport", _u32,
    [_c_char_p, _c_char_p, _c_char_p, _u16, _i32,
     ctypes.POINTER(_void_p)])
robotos_node_shutdown = _sig("robotos_node_shutdown", _u32, [_void_p])
robotos_node_graph_json = _sig(
    "robotos_node_graph_json", _u32,
    [_void_p, _u32, _c_char_p, _size_t, ctypes.POINTER(_size_t)])
robotos_node_destroy = _sig("robotos_node_destroy", None, [_void_p])

robotos_publisher_create = _sig(
    "robotos_publisher_create", _u32,
    [_void_p, _c_char_p, _c_char_p, ctypes.POINTER(_void_p)])
robotos_publish = _sig(
    "robotos_publish", _u32, [_void_p, _u8_p, _size_t])
robotos_publisher_destroy = _sig(
    "robotos_publisher_destroy", None, [_void_p])

robotos_subscriber_create = _sig(
    "robotos_subscriber_create", _u32,
    [_void_p, _c_char_p, _c_char_p, ctypes.POINTER(_void_p)])
robotos_subscriber_recv_owned = _sig(
    "robotos_subscriber_recv_owned", _u32,
    [_void_p, ctypes.POINTER(Message), _u32])
robotos_message_free = _sig(
    "robotos_message_free", None, [ctypes.POINTER(Message)])
robotos_subscriber_set_callback = _sig(
    "robotos_subscriber_set_callback", _u32,
    [_void_p, MESSAGE_CALLBACK, _void_p])
robotos_subscriber_clear_callback = _sig(
    "robotos_subscriber_clear_callback", _u32, [_void_p])
robotos_subscriber_destroy = _sig(
    "robotos_subscriber_destroy", None, [_void_p])

robotos_presence_get = _sig(
    "robotos_presence_get", _u32,
    [_void_p, _c_char_p, PRESENCE_CALLBACK, _void_p,
     ctypes.POINTER(_size_t)])
robotos_presence_watch = _sig(
    "robotos_presence_watch", _u32,
    [_void_p, _c_char_p, PRESENCE_CALLBACK, _void_p,
     ctypes.POINTER(_void_p)])
robotos_presence_watch_destroy = _sig(
    "robotos_presence_watch_destroy", None, [_void_p])
robotos_presence_declare = _sig(
    "robotos_presence_declare", _u32,
    [_void_p, _c_char_p, ctypes.POINTER(_void_p)])
robotos_presence_token_destroy = _sig(
    "robotos_presence_token_destroy", None, [_void_p])

# ---- services ---------------------------------------------------------------

robotos_service_create = _sig(
    "robotos_service_create", _u32,
    [_void_p, _c_char_p, _c_char_p, _c_char_p,
     SERVICE_HANDLER, _void_p, ctypes.POINTER(_void_p)])
robotos_service_destroy = _sig(
    "robotos_service_destroy", None, [_void_p])
robotos_client_call = _sig(
    "robotos_client_call", _u32,
    [_void_p, _c_char_p, _c_char_p, _c_char_p,
     _u8_p, _size_t, _u32, ctypes.POINTER(Message)])

# ---- parameters ---------------------------------------------------------------

robotos_param_allow_remote = _sig(
    "robotos_param_allow_remote", None, [_void_p, _i32])
robotos_param_on_set = _sig(
    "robotos_param_on_set", _u32, [_void_p, PARAM_SET_CB, _void_p])

robotos_lifecycle_get = _sig("robotos_lifecycle_get", _u32, [_void_p])
for _t in ("configure", "activate", "deactivate", "cleanup"):
    globals()[f"robotos_lifecycle_{_t}"] = _sig(
        f"robotos_lifecycle_{_t}", _u32, [_void_p])
robotos_lifecycle_allow_remote = _sig(
    "robotos_lifecycle_allow_remote", None, [_void_p, _i32])
robotos_lifecycle_on = _sig(
    "robotos_lifecycle_on", _u32, [_void_p, _i32, LIFECYCLE_CB, _void_p])

for _t, _ct in (("i64", ctypes.c_int64), ("f64", ctypes.c_double),
                ("bool", _i32)):
    globals()[f"robotos_param_declare_{_t}"] = _sig(
        f"robotos_param_declare_{_t}", _u32,
        [_void_p, _c_char_p, _ct, ctypes.POINTER(ParamDescriptor)])
    globals()[f"robotos_param_get_{_t}"] = _sig(
        f"robotos_param_get_{_t}", _u32,
        [_void_p, _c_char_p, ctypes.POINTER(_ct)])
    globals()[f"robotos_param_set_{_t}"] = _sig(
        f"robotos_param_set_{_t}", _u32,
        [_void_p, _c_char_p, _ct])

robotos_param_declare_string = _sig(
    "robotos_param_declare_string", _u32,
    [_void_p, _c_char_p, _c_char_p, ctypes.POINTER(ParamDescriptor)])
robotos_param_get_string = _sig(
    "robotos_param_get_string", _u32,
    [_void_p, _c_char_p, _c_char_p, _size_t, ctypes.POINTER(_size_t)])
robotos_param_set_string = _sig(
    "robotos_param_set_string", _u32,
    [_void_p, _c_char_p, _c_char_p])

# ---- actions -----------------------------------------------------------------

# u32 handler(goal, goal_len, goal_ctx, result_buf, result_cap,
#             result_len_out, user)
ACTION_HANDLER = ctypes.CFUNCTYPE(
    _u32, _u8_p, _size_t, _void_p, _u8_p, _size_t,
    ctypes.POINTER(_size_t), _void_p)


robotos_action_server_create = _sig(
    "robotos_action_server_create", _u32,
    [_void_p, _c_char_p, ACTION_HANDLER, _void_p,
     ctypes.POINTER(_void_p)])
robotos_action_server_destroy = _sig(
    "robotos_action_server_destroy", None, [_void_p])
robotos_goal_cancel_requested = _sig(
    "robotos_goal_cancel_requested", _i32, [_void_p])
robotos_goal_send_feedback = _sig(
    "robotos_goal_send_feedback", _u32,
    [_void_p, _u8_p, _size_t])
robotos_action_client_create = _sig(
    "robotos_action_client_create", _u32,
    [_void_p, _c_char_p, ctypes.POINTER(_void_p)])
robotos_action_client_destroy = _sig(
    "robotos_action_client_destroy", None, [_void_p])
robotos_action_send_goal = _sig(
    "robotos_action_send_goal", _u32,
    [_void_p, _u8_p, _size_t, _u32, _c_char_p, _size_t,
     ctypes.POINTER(_size_t)])
robotos_action_cancel = _sig(
    "robotos_action_cancel", _u32,
    [_void_p, _c_char_p, _u32, ctypes.POINTER(_u32)])
robotos_action_result = _sig(
    "robotos_action_result", _u32,
    [_void_p, _c_char_p, _u32, ctypes.POINTER(_u32),
     ctypes.POINTER(Message)])
robotos_action_feedback_recv = _sig(
    "robotos_action_feedback_recv", _u32,
    [_void_p, _c_char_p, _u32, ctypes.POINTER(Message)])

# ---- record / replay ----------------------------------------------------------

robotos_recorder_create = _sig(
    "robotos_recorder_create", _u32,
    [_void_p, _c_char_p, _c_char_p, _c_char_p, ctypes.POINTER(_void_p)])
robotos_recorder_count = _sig(
    "robotos_recorder_count", ctypes.c_uint64, [_void_p])
robotos_recorder_stop = _sig(
    "robotos_recorder_stop", _u32, [_void_p])
robotos_recorder_destroy = _sig(
    "robotos_recorder_destroy", None, [_void_p])


class ReplayReport(ctypes.Structure):
    _fields_ = [
        ("published", ctypes.c_uint64),
        ("skipped_command", ctypes.c_uint64),
        ("skipped_filter", ctypes.c_uint64),
        ("failed", ctypes.c_uint64),
    ]


robotos_replay = _sig(
    "robotos_replay", _u32,
    [_void_p, _c_char_p, ctypes.c_double, _i32, _c_char_p, _c_char_p,
     ctypes.POINTER(ReplayReport)])
robotos_bag_info = _sig(
    "robotos_bag_info", _u32,
    [_c_char_p, _c_char_p, _size_t, ctypes.POINTER(_size_t)])


import threading as _threading


class HandleGuard:
    """In-flight call tracking for one FFI handle. close() flips the
    flag so new calls fail, then waits for in-flight calls to leave —
    the destroy can't free the handle under a running FFI call (the
    use-after-free class flagged in review)."""

    def __init__(self):
        self._lock = _threading.Condition()
        self._inflight = 0
        self._closing = False

    def enter(self):
        with self._lock:
            if self._closing:
                return False
            self._inflight += 1
            return True

    def exit(self):
        with self._lock:
            self._inflight -= 1
            if self._inflight == 0:
                self._lock.notify_all()

    @property
    def closing(self):
        return self._closing

    def close(self):
        with self._lock:
            self._closing = True
            while self._inflight:
                self._lock.wait(0.05)
