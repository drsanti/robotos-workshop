"""Status codes → exceptions. Mirrors `robotos_status_t`."""

from __future__ import annotations

from . import _ffi


class RobotosError(Exception):
    def __init__(self, status: int, context: str = ""):
        self.status = status
        self.status_name = STATUS_NAMES.get(status, f"STATUS_{status}")
        detail = _ffi.robotos_last_error()
        msg = f"{context}: {self.status_name}"
        if detail:
            msg += f" ({detail.decode('utf-8', 'replace')})"
        super().__init__(msg)


STATUS_NAMES = {
    0: "OK",
    1: "INVALID_ARGUMENT",
    2: "TRANSPORT_ERROR",
    3: "NOT_INITIALIZED",
    4: "SHUTDOWN",
    5: "CHANNEL_CLOSED",
    6: "PAYLOAD_TOO_LARGE",
    7: "PROTOCOL_ERROR",
    8: "TIMEOUT",
    9: "INVALID_STATE",
    10: "UNAVAILABLE",
    11: "AMBIGUOUS_RESPONDER",
    12: "CANCELLED",
    13: "DEADLINE_EXCEEDED",
    14: "RESOURCE_EXHAUSTED",
    15: "NOT_FOUND",
    255: "ERROR",
}

OK = 0
TIMEOUT = 8
CHANNEL_CLOSED = 5
SHUTDOWN = 4


def check(status: int, context: str) -> None:
    if status != OK:
        raise RobotosError(status, context)
